﻿Public Class frmLogin
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If txtUsername.Text = "Admin" And txtpassword.Text = "1234" Then
            MsgBox("Royal Restaurant in Service")
        Else
            MsgBox("wrong credentials")
        End If
        frmManage.Show()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        frmMain.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        frmSearch.Show()
    End Sub



    Private Sub Button3_Click_2(sender As Object, e As EventArgs)
        frmOrders.Show()
    End Sub
End Class