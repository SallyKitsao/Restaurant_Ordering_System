﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSearch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        rdoMenuItem = New RadioButton()
        rdoCustomer = New RadioButton()
        lblSearch = New Label()
        cboSearch = New ComboBox()
        lblKeyword = New Label()
        txtKeyword = New TextBox()
        btnSearch = New Button()
        dgvSearch = New DataGridView()
        Label1 = New Label()
        CType(dgvSearch, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' rdoMenuItem
        ' 
        rdoMenuItem.AutoSize = True
        rdoMenuItem.Location = New Point(34, 79)
        rdoMenuItem.Name = "rdoMenuItem"
        rdoMenuItem.Size = New Size(88, 19)
        rdoMenuItem.TabIndex = 0
        rdoMenuItem.TabStop = True
        rdoMenuItem.Text = "MENU ITEM"
        rdoMenuItem.UseVisualStyleBackColor = True
        ' 
        ' rdoCustomer
        ' 
        rdoCustomer.AutoSize = True
        rdoCustomer.Location = New Point(163, 79)
        rdoCustomer.Name = "rdoCustomer"
        rdoCustomer.Size = New Size(85, 19)
        rdoCustomer.TabIndex = 1
        rdoCustomer.TabStop = True
        rdoCustomer.Text = "CUSTOMER"
        rdoCustomer.UseVisualStyleBackColor = True
        ' 
        ' lblSearch
        ' 
        lblSearch.AutoSize = True
        lblSearch.Location = New Point(34, 43)
        lblSearch.Name = "lblSearch"
        lblSearch.Size = New Size(71, 15)
        lblSearch.TabIndex = 2
        lblSearch.Text = "SEARCH BY:"
        ' 
        ' cboSearch
        ' 
        cboSearch.FormattingEnabled = True
        cboSearch.Location = New Point(34, 122)
        cboSearch.Name = "cboSearch"
        cboSearch.Size = New Size(121, 23)
        cboSearch.TabIndex = 3
        ' 
        ' lblKeyword
        ' 
        lblKeyword.AutoSize = True
        lblKeyword.Location = New Point(34, 163)
        lblKeyword.Name = "lblKeyword"
        lblKeyword.Size = New Size(99, 15)
        lblKeyword.TabIndex = 4
        lblKeyword.Text = "ENTER KEYWORD"
        ' 
        ' txtKeyword
        ' 
        txtKeyword.Location = New Point(175, 160)
        txtKeyword.Name = "txtKeyword"
        txtKeyword.Size = New Size(100, 23)
        txtKeyword.TabIndex = 5
        ' 
        ' btnSearch
        ' 
        btnSearch.Location = New Point(34, 212)
        btnSearch.Name = "btnSearch"
        btnSearch.Size = New Size(75, 23)
        btnSearch.TabIndex = 6
        btnSearch.Text = "SEARCH"
        btnSearch.UseVisualStyleBackColor = True
        ' 
        ' dgvSearch
        ' 
        dgvSearch.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvSearch.Location = New Point(34, 256)
        dgvSearch.Name = "dgvSearch"
        dgvSearch.Size = New Size(599, 228)
        dgvSearch.TabIndex = 7
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(379, 31)
        Label1.Name = "Label1"
        Label1.Size = New Size(153, 15)
        Label1.TabIndex = 8
        Label1.Text = "ROYAL RESTAURANT MENU"
        ' 
        ' frmSearch
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.back
        ClientSize = New Size(1118, 532)
        Controls.Add(Label1)
        Controls.Add(dgvSearch)
        Controls.Add(btnSearch)
        Controls.Add(txtKeyword)
        Controls.Add(lblKeyword)
        Controls.Add(cboSearch)
        Controls.Add(lblSearch)
        Controls.Add(rdoCustomer)
        Controls.Add(rdoMenuItem)
        FormBorderStyle = FormBorderStyle.None
        Name = "frmSearch"
        Text = "frmSearch"
        CType(dgvSearch, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents rdoMenuItem As RadioButton
    Friend WithEvents rdoCustomer As RadioButton
    Friend WithEvents lblSearch As Label
    Friend WithEvents cboSearch As ComboBox
    Friend WithEvents lblKeyword As Label
    Friend WithEvents txtKeyword As TextBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents dgvSearch As DataGridView
    Friend WithEvents Label1 As Label
End Class
