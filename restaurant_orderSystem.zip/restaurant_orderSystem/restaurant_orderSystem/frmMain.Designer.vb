﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblTitle = New Label()
        lblMenu = New Label()
        lblOrder = New Label()
        lblTotal = New Label()
        lstMenu = New ListBox()
        lstOrder = New ListBox()
        btnAdd = New Button()
        btnRemove = New Button()
        btnPrint = New Button()
        btnClear = New Button()
        btnExit = New Button()
        txtTotal = New TextBox()
        txtQuantity = New TextBox()
        SuspendLayout()
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Location = New Point(284, 9)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(116, 15)
        lblTitle.TabIndex = 0
        lblTitle.Text = "ROYAL RESTAURANT"
        ' 
        ' lblMenu
        ' 
        lblMenu.AutoSize = True
        lblMenu.Location = New Point(60, 57)
        lblMenu.Name = "lblMenu"
        lblMenu.Size = New Size(41, 15)
        lblMenu.TabIndex = 1
        lblMenu.Text = "MENU"
        ' 
        ' lblOrder
        ' 
        lblOrder.AutoSize = True
        lblOrder.Location = New Point(62, 186)
        lblOrder.Name = "lblOrder"
        lblOrder.Size = New Size(44, 15)
        lblOrder.TabIndex = 2
        lblOrder.Text = "ORDER"
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.Location = New Point(406, 279)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(39, 15)
        lblTotal.TabIndex = 3
        lblTotal.Text = "TOTAL"
        ' 
        ' lstMenu
        ' 
        lstMenu.FormattingEnabled = True
        lstMenu.ItemHeight = 15
        lstMenu.Location = New Point(62, 75)
        lstMenu.Name = "lstMenu"
        lstMenu.Size = New Size(338, 94)
        lstMenu.TabIndex = 4
        ' 
        ' lstOrder
        ' 
        lstOrder.FormattingEnabled = True
        lstOrder.ItemHeight = 15
        lstOrder.Location = New Point(60, 204)
        lstOrder.Name = "lstOrder"
        lstOrder.Size = New Size(340, 94)
        lstOrder.TabIndex = 5
        ' 
        ' btnAdd
        ' 
        btnAdd.Location = New Point(420, 75)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(75, 23)
        btnAdd.TabIndex = 6
        btnAdd.Text = "ADD"
        btnAdd.UseVisualStyleBackColor = True
        ' 
        ' btnRemove
        ' 
        btnRemove.Location = New Point(420, 120)
        btnRemove.Name = "btnRemove"
        btnRemove.Size = New Size(75, 23)
        btnRemove.TabIndex = 7
        btnRemove.Text = "REMOVE"
        btnRemove.UseVisualStyleBackColor = True
        ' 
        ' btnPrint
        ' 
        btnPrint.Location = New Point(60, 326)
        btnPrint.Name = "btnPrint"
        btnPrint.Size = New Size(75, 23)
        btnPrint.TabIndex = 8
        btnPrint.Text = "PRINT"
        btnPrint.UseVisualStyleBackColor = True
        ' 
        ' btnClear
        ' 
        btnClear.Location = New Point(156, 326)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(75, 23)
        btnClear.TabIndex = 9
        btnClear.Text = "CLEAR"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' btnExit
        ' 
        btnExit.Location = New Point(256, 326)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(75, 23)
        btnExit.TabIndex = 10
        btnExit.Text = "EXIT"
        btnExit.UseVisualStyleBackColor = True
        ' 
        ' txtTotal
        ' 
        txtTotal.Location = New Point(451, 276)
        txtTotal.Name = "txtTotal"
        txtTotal.Size = New Size(100, 23)
        txtTotal.TabIndex = 11
        ' 
        ' txtQuantity
        ' 
        txtQuantity.Location = New Point(406, 204)
        txtQuantity.Name = "txtQuantity"
        txtQuantity.Size = New Size(100, 23)
        txtQuantity.TabIndex = 12
        ' 
        ' frmMain
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.back
        ClientSize = New Size(800, 450)
        Controls.Add(txtQuantity)
        Controls.Add(txtTotal)
        Controls.Add(btnExit)
        Controls.Add(btnClear)
        Controls.Add(btnPrint)
        Controls.Add(btnRemove)
        Controls.Add(btnAdd)
        Controls.Add(lstOrder)
        Controls.Add(lstMenu)
        Controls.Add(lblTotal)
        Controls.Add(lblOrder)
        Controls.Add(lblMenu)
        Controls.Add(lblTitle)
        FormBorderStyle = FormBorderStyle.None
        Name = "frmMain"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents lblMenu As Label
    Friend WithEvents lblOrder As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents lstMenu As ListBox
    Friend WithEvents lstOrder As ListBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnRemove As Button
    Friend WithEvents btnPrint As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents txtQuantity As TextBox

End Class
